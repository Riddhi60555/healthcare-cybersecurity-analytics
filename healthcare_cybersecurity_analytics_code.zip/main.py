from src.log_ingestion import ingest_logs
from src.anomaly_detection import detect_anomalies
from src.risk_scoring import calculate_risk

logs = ingest_logs()
alerts = detect_anomalies(logs)
risk = calculate_risk(alerts)

print(risk)
