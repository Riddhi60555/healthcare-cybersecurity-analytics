def calculate_risk(alerts):
    return [{"user": a["user"], "risk": "HIGH"} for a in alerts]
