def detect_anomalies(logs):
    alerts = []
    for log in logs:
        if log.get("failed_attempts", 0) > 5:
            alerts.append(log)
    return alerts
