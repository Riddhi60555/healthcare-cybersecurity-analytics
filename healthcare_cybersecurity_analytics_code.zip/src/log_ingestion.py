def ingest_logs():
    return [
        {"user": "doctor1", "failed_attempts": 2},
        {"user": "nurse2", "failed_attempts": 7}
    ]
