# Healthcare Cybersecurity Analytics Platform

This project demonstrates a healthcare-focused cybersecurity analytics system.
It analyzes login events, detects anomalies, and supports HIPAA-aware security monitoring.

## Features
- Log ingestion
- Anomaly detection
- Risk scoring
- Simple reporting

## Tech
Python, GitHub
